<?php

namespace App\Services;

class SuPuRuiLocationService
{

}
