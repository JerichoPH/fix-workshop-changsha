<?php

namespace App\Console\Commands;

use App\Model\Measurement;
use Exception;
use Illuminate\Console\Command;

class MeasurementCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'measurement:ifj {filename}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'import measurement from json';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        try {
            $filename = $this->argument('filename');

            if (!file_exists(storage_path("{$filename}.json"))) {
                $this->error("file: {$filename} is doesn't exists");
                return 1;
            }

            $file_content = json_decode(file_get_contents(storage_path("{$filename}.json")), true);
            $count = 0;

            foreach ($file_content['ModelConverters'] as $item) {
                [
                    'ParamConverters' => $measurements,
                    '名称' => $sub_model_name,
                    '编号' => $sub_model_unique_code,
                ] = $item;
                $count += count($measurements);

                foreach ($measurements as $measurement) {
                    ['名称' => $measurement_key, '标准值' => $allow_value, '编号' => $measurement_serial_number,] = $measurement;
                    if ($measurement_serial_number) {
                        $measurement_obj = Measurement::with([])->where('serial_number', $measurement_serial_number);
                        if ($measurement_obj) continue;
                    }
                    $allow_value = '';
                }
            }
            dd($count);

            return 0;
        } catch (Exception $e) {
            $this->error($e->getMessage());
            $this->error($e->getFile());
            $this->error($e->getLine());
            return -1;
        }
    }
}
