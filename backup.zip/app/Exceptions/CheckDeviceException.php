<?php

namespace App\Exceptions;

use Exception;

class CheckDeviceException extends Exception
{
    //
}
