<?php

namespace App\Exceptions;

use Exception;

class WechatException extends Exception
{
    //
}
