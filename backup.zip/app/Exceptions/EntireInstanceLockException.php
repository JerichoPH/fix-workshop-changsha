<?php

namespace App\Exceptions;

use Exception;

class EntireInstanceLockException extends Exception
{
    //
}
