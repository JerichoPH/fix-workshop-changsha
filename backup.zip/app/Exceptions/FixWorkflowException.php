<?php

namespace App\Exceptions;

use Exception;

class FixWorkflowException extends Exception
{
    //
}
