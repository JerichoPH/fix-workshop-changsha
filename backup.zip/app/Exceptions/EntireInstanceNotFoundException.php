<?php

namespace App\Exceptions;

use Exception;

class EntireInstanceNotFoundException extends Exception
{
    //
}
