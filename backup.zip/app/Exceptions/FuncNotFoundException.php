<?php

namespace App\Exceptions;

use Exception;

class FuncNotFoundException extends Exception
{
    //
}
