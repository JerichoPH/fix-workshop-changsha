<?php

namespace App\Exceptions;

use Exception;

class ExcelInException extends Exception
{
    //
}
