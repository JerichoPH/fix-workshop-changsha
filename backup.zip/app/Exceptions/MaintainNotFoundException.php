<?php

namespace App\Exceptions;

use Exception;

class MaintainNotFoundException extends Exception
{
    //
}
